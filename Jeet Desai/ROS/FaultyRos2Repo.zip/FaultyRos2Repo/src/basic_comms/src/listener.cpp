#include "rclcpp/rclcpp.hpp"

// BUG 3: Wrong message type included — should be std_msgs/msg/string.hpp
// Int32 does not match what the talker publishes (String), so this won't compile cleanly
// and even if forced, will never receive the messages
#include "std_msgs/msg/string.hpp"

class Listener : public rclcpp::Node
{
public:
  Listener() : Node("listener")
  {
    // Also subscribing to wrong topic name: "/chattar" instead of "/chatter"
    subscription_ = this->create_subscription<std_msgs::msg::String>(
      "/chatter", 10,
      std::bind(&Listener::on_message, this, std::placeholders::_1)
    );

    RCLCPP_INFO(this->get_logger(), "Listener node started, waiting for messages...");
  }

private:
  void on_message(const std_msgs::msg::String::SharedPtr msg)
  {
    RCLCPP_INFO(this->get_logger(), "Received: '%s'", msg->data.c_str());
  }

  rclcpp::Subscription<std_msgs::msg::String>::SharedPtr subscription_;
};

int main(int argc, char * argv[])
{
  rclcpp::init(argc, argv);
  rclcpp::spin(std::make_shared<Listener>());
  rclcpp::shutdown();
  return 0;
}
