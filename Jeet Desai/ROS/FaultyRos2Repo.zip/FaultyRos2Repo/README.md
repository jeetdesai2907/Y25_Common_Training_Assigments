# basic_comms

A ROS2 package for robot communication.

## What it does

There is a talker node and a listener node. The talker sends messages. The listener receives them.

## Requirements

- ROS2 (tested on Humble)
- colcon

## Notes

- Something might not work. Check the code.
- Launch file is in the `launch/` folder.
- Good luck.
